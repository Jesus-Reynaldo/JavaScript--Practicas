let altura_cm = 163;
let altura_m = 1.63;
let peso_kg = 56.6;
let altura = altura_m.toFixed();
console.log(altura);
let peso = parseInt(peso_kg);
console.log(peso);
let maximo = Number.MAX_VALUE + 1 === Number.MAX_VALUE;
console.log(maximo);
