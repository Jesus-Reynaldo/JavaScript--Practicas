// factorial while
let factorial =1;
let producto = 1;
while (producto<=10){
  factorial*=producto;
  producto++;
}
console.log(factorial);