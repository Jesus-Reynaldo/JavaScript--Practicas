const familia = new Set(["Jesus", "Fernando", "Reinaldo", "Javier"]);
familia.add("Jesus");
console.log(familia);
familia.add("Javascript");
console.log(familia);
